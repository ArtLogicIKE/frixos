"""Text platform for Frixos integration."""
from __future__ import annotations

from homeassistant.components.text import TextEntity, TextEntityDescription
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import (
    DOMAIN,
    PARAM_HOSTNAME,
    PARAM_MESSAGE,
    PARAM_LATITUDE,
    PARAM_LONGITUDE,
    PARAM_TIMEZONE,
    PARAM_HA_URL,
    PARAM_HA_TOKEN,
    PARAM_STOCK_KEY,
    PARAM_DEXCOM_USERNAME,
    PARAM_DEXCOM_PASSWORD,
    PASSWORD_PARAMS,
)
from .coordinator import FrixosDataUpdateCoordinator
from .entity import FrixosEntity

# Map parameter keys to their max lengths
TEXT_MAX_LENGTHS = {
    PARAM_HOSTNAME: 32,
    PARAM_MESSAGE: 511,
    PARAM_LATITUDE: 12,
    PARAM_LONGITUDE: 12,
    PARAM_TIMEZONE: 64,
    PARAM_HA_URL: 200,
    PARAM_HA_TOKEN: 255,
    PARAM_STOCK_KEY: 64,
    PARAM_DEXCOM_USERNAME: 64,
    PARAM_DEXCOM_PASSWORD: 64,
}

TEXT_DESCRIPTIONS: tuple[TextEntityDescription, ...] = (
    TextEntityDescription(
        key=PARAM_HOSTNAME,
        name="Hostname",
        icon="mdi:network",
    ),
    TextEntityDescription(
        key=PARAM_MESSAGE,
        name="Scrolling Message",
        icon="mdi:message-text",
    ),
    TextEntityDescription(
        key=PARAM_LATITUDE,
        name="Latitude",
        icon="mdi:latitude",
    ),
    TextEntityDescription(
        key=PARAM_LONGITUDE,
        name="Longitude",
        icon="mdi:longitude",
    ),
    TextEntityDescription(
        key=PARAM_TIMEZONE,
        name="Timezone",
        icon="mdi:map-clock",
    ),
    TextEntityDescription(
        key=PARAM_HA_URL,
        name="Home Assistant URL",
        icon="mdi:home-assistant",
    ),
    TextEntityDescription(
        key=PARAM_HA_TOKEN,
        name="Home Assistant Token",
        icon="mdi:key",
    ),
    TextEntityDescription(
        key=PARAM_STOCK_KEY,
        name="Stock API Key",
        icon="mdi:key",
    ),
    TextEntityDescription(
        key=PARAM_DEXCOM_USERNAME,
        name="Dexcom Username",
        icon="mdi:account",
    ),
    TextEntityDescription(
        key=PARAM_DEXCOM_PASSWORD,
        name="Dexcom Password",
        icon="mdi:key",
    ),
)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up Frixos text entities."""
    coordinator: FrixosDataUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]

    entities = [
        FrixosText(coordinator, description)
        for description in TEXT_DESCRIPTIONS
    ]

    async_add_entities(entities)


class FrixosText(FrixosEntity, TextEntity):
    """Representation of a Frixos text entity."""

    def __init__(
        self,
        coordinator: FrixosDataUpdateCoordinator,
        description: TextEntityDescription,
    ) -> None:
        """Initialize the text entity."""
        super().__init__(
            coordinator,
            f"{coordinator.host}_{description.key}",
            f"Frixos {description.name}",
            description.icon,
        )
        self.entity_description = description
        self._attr_native_min = 0
        # Get max length from our mapping
        self._attr_native_max = TEXT_MAX_LENGTHS.get(description.key, 255)
        # Set password mode for sensitive fields
        if description.key in PASSWORD_PARAMS:
            self._attr_mode = "password"

    @property
    def native_value(self) -> str | None:
        """Return the current value."""
        if not self.coordinator.data or not isinstance(self.coordinator.data, dict):
            return ""
        
        settings = self.coordinator.data.get("settings", {})
        if not isinstance(settings, dict):
            return ""
        
        value = settings.get(self.entity_description.key)
        return str(value) if value is not None else ""

    async def async_set_value(self, value: str) -> None:
        """Update the current value."""
        success = await self.coordinator.async_set_setting(self.entity_description.key, value)
        if success:
            self.async_write_ha_state()
